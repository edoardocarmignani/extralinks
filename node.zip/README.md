<div align="center">
    <img src="imgs/extralinks_logo.png">
</div>



A one-click collection of alternate connection styles for ComfyUI.

------------------------------------------------------------------

<div align="center">
    <img width=400 height=190 src="imgs/curved.png">
    <img width=400 height=190 src="imgs/rounded.png">
</div>

<div align="center">
    <img width=800 src="imgs/extralinks_example.gif">
</div>
